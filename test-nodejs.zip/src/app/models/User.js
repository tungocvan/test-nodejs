// http://expressjs.com/en/starter/hello-world.html
// https://www.npmjs.com/package/mongoose-slug-generator
// https://mongoosejs.com/docs/documents.html
// https://www.npmjs.com/package/mongoose-delete
const mongoose = require('mongoose');
const { Schema } = mongoose;
const User = new Schema({
  name: String,
  password: String,
  email: String
});
module.exports = mongoose.model('User',User);