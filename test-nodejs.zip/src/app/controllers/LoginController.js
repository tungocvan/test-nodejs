class LoginController {
    // [GET] /me/stored/courses
    
    index(req, res,next) {
      //req.logout();  
            
      if(req.isAuthenticated()) {
          res.redirect('/');          
      }else{
        
        res.render('users/login',{ layout : 'layoutLogin' , login:true, message:req.flash('error')[0]})
      }
       
    }   
  }
  
module.exports = new LoginController();
  