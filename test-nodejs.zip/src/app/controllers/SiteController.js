//const modelUser = require('../models/User');
//const {mutileMongooseToObject , mongooseToObject} = require('./mongoose');
const Buffer = require('buffer/').Buffer
var fs = require("fs");
const https = require("https");
var data = '';
var path = require("path");
class SiteController {
  // [GET] /
  index(req, res) {    
    console.log(__filename);
    //console.log( __dirname ); 
    console.log(path.parse(__filename));
    res.render('home');
  } 
  stream(req, res) {    
    let t =  global.basedir +  '/public/data.txt'; 
    //let t='https://estacks.icu/img/me.png'; // stream đọc được file local server 
    var readerStream = fs.createReadStream(t);
    // Thiet lap encoding la utf8. 
    readerStream.setEncoding('UTF8');
    // Xu ly cac su kien lien quan toi Stream: data, end, va error
    readerStream.on('data', function(chunk) {
      console.log('chunk:',chunk.length);
      data += chunk;
    });
    readerStream.on('end', function(){
      console.log(data.length);
    });
    readerStream.on('error', function(err){
      console.log(err.stack);
    });
    console.log("Ket thuc chuong trinh");
    res.render('home');
  } 
  buffer(req, res) {    
    let buf = new Buffer(256);
    let len = buf.write("Hoc Nodejs tai VietTutsa");
    console.log("buf: " + buf.toString());
    var buffer2 = buf.slice(4, 11);
    console.log("buffer2: " + buffer2.toString());
    res.render('home');
  } 
  fsfile(req, res) {    
    let t =  global.basedir +  '/public/data.txt';    
    fs.readFile(t, function (err, data) {
      if (err) {
          return console.error(err);
      }
      console.log("Phuong thuc doc file khong dong bo: " + data.toString());
   });
    res.render('home');
  } 
  readUrl(req, res){
      let tBackup =  global.basedir +  '/public/product-1.json';
      let t='https://tiki.vn/api/v2/products/72660053'; 
      const file = fs.createWriteStream(tBackup);
      https.get(t, response => {
        var stream = response.pipe(file);
        stream.on("finish", function() {
          console.log("done");
        });
      });
       res.render('home');
  }
}

module.exports = new SiteController();
