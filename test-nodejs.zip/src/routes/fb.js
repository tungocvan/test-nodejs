// https://developers.facebook.com/apps/214306215716895/dashboard/
// https://viblo.asia/p/login-facebook-with-passport-on-nodejs-Do7546p0ZM6
const express = require('express');
const router = express.Router();
const config = require('../config/db/');
const passport = require('passport');
const FacebookStrategy  = require('passport-facebook').Strategy;
const fs = require('fs');
router.get('/fb',passport.authenticate('facebook',{scope:'email'}));
router.get('/fb/cb',
	  passport.authenticate('facebook', { successRedirect : '/', failureRedirect: '/users/login' }),
	  function(req, res) {
	    res.redirect('/');
});
router.get('/logout', function(req, res){
    req.logout();
    res.redirect('/');
});

passport.use(new FacebookStrategy({
    clientID: config.facebook_key,
    clientSecret:config.facebook_secret ,
    callbackURL: config.callback_url,
    profileFields: ['id', 'displayName', 'photos', 'email']
  },
  function(accessToken, refreshToken, profile, done) {
    process.nextTick(function () {
      const myUser = {
        //accesstoken: accessToken,               
        firstName: profile.displayName,
        lastName: '',
        email: profile._json.email,
        password:'',
        phone:'',
        birthday:'',
        avatar: profile.photos[0].value
      };
	  global.profile = myUser;
      return done(null, myUser.email);
    });
  }
));

module.exports = router;
