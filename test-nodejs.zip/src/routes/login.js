const express = require('express');
const router = express.Router();
const passport = require('passport');
const localStrategy = require('passport-local').Strategy;

const loginController = require('../app/controllers/LoginController');

router.get('/', loginController.index);
router.post('/',passport.authenticate('local', {
    failureRedirect: 'users/login',  
    successRedirect: '/',
    failureFlash : true // allow flash messages
}));

passport.use(new localStrategy(
    (username, password, done) => { //các tên - name trường cần nhập, đủ tên trường thì Done 
        // sử dụng mongodb

        // const modelUser = require('../app/models/User');
        // modelUser.find({email:username}).then((user)=>{
        //         if(user[0].password === password ){
        //             // console.log('user:',user)
        //             global.profile = user[0];
        //             return done(null, username); //trả về username
        //         }else{                    
        //             return done(null, false,{message :'Mật khẩu không đúng.!!!'}); //chứng thực lỗi
        //         }
        // }).catch(()=>{
        //     return done(null, false,{message :'username không tồn tại .!!!'}); //chứng thực lỗi
        // })       
        
        // sử dụng file users.json
        
        const fs = require('fs');
        let t =  global.basedir +  '/public/json/users.json';        
        fs.readFile(t, function read(err, data) {
            if (err)   throw err;
            var users = JSON.parse(data); 
            // console.log('users:',users.data[0]);
            for (let i = 0; i < users.data.length; i++) {              
                if(username === users.data[i].email && password === users.data[i].password) {
                    global.profile = users.data[i];
                    return done(null, username); //trả về username
                }
                
            }
            return done(null, false,{message :'username hoặc password không đúng .!!!'}); //chứng thực lỗi
        });

    }
))

module.exports = router;
