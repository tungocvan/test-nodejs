const express = require('express');
const router = express.Router();
const config = require('../config/db/');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

router.get('/',passport.authenticate('google',{scope: ['profile', 'email']}));
router.get('/cb',
	  passport.authenticate('google', { successRedirect : '/', failureRedirect: '/login' }),
	  function(req, res) {
	    res.redirect('/');
});

passport.use(
    new GoogleStrategy(
      {
        clientID: config.googleClientID,
        clientSecret: config.googleClientSecret,
        callbackURL: config.googleUrl
      }, 
      function(accessToken, refreshToken, profile, done) {
          process.nextTick(function () {         
            //Lưu thông tin account google đăng nhập           
            const account = {
                id : profile.id,
                email: profile.emails[0].value,
                displayName : profile.displayName,
                photos : profile.photos[0].value
            };
            //console.log('profile:',account);
            global.profile = account
            return done(null,account.email);
         });

      }
    )
);

module.exports = router;
