const express = require('express');
const router = express.Router();

const siteController = require('../app/controllers/SiteController');

router.get('/', siteController.index);
router.get('/buffer', siteController.buffer);
router.get('/stream', siteController.stream);
router.get('/fsfile', siteController.fsfile);
router.get('/product', siteController.readUrl);
 
module.exports = router;
